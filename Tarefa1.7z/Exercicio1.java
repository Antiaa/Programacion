
import java.util.Scanner;

public class Exercicio1 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        double binario = 0, decimal;
        do {
            System.out.println("Introduce un número mayor que 0 y menor que 9999");
            decimal = leer.nextInt();
        } while ((decimal < 0) && (decimal > 9999));

        for (int i = 0; i < decimal; i++) {
            binario = decimal % 2;
        }
        System.out.println("El número binario es: " + binario);
    }

}
