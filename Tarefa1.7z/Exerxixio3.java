
import java.util.Scanner;

public class Exerxixio3 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Introduce un número de 10 dígitos");
        int num = leer.nextInt();
        int resto = 0;
        while (num % 97 == resto) {
            if (resto < 10) {
                System.out.println("El dígito de control es: 0" + resto);
            } else {
                System.out.println("El dígito de control es: " + resto);
            }

        }
    }
}
