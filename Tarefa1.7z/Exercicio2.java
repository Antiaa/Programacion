
import java.util.Scanner;

public class Exercicio2 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Introduce un número para iniciar la serie");
        int numero = leer.nextInt();
        while (numero != 1) {
            if (numero % 2 == 0) {
                numero = numero / 2;
            } else {
                numero = numero * 3 + 1;
            }
            System.out.println(numero + " ");
        }
    }
}
